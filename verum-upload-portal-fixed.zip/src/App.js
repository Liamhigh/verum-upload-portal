import React, { useState } from "react";
import UploadPortal from "./UploadPortal";

function App() {
  return (
    <div>
      <h1 style={{ textAlign: "center", marginTop: "40px" }}>Verum Omnis Upload Portal</h1>
      <UploadPortal />
    </div>
  );
}

export default App;
