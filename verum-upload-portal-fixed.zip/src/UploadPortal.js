import React, { useState } from "react";

function UploadPortal() {
  const [role, setRole] = useState("");
  const [file, setFile] = useState(null);

  const handleRoleChange = (e) => {
    setRole(e.target.value);
  };

  const handleFileChange = (e) => {
    setFile(e.target.files[0]);
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    if (file && role) {
      alert("File uploaded successfully as " + role);
    } else {
      alert("Please select a role and a file.");
    }
  };

  return (
    <form onSubmit={handleSubmit} style={{ textAlign: "center", marginTop: "20px" }}>
      <label>
        I am a:
        <select value={role} onChange={handleRoleChange}>
          <option value="">Select</option>
          <option value="private">Private Individual</option>
          <option value="company">Company</option>
          <option value="institution">Institution</option>
        </select>
      </label>
      <br /><br />
      <input type="file" onChange={handleFileChange} />
      <br /><br />
      <button type="submit">Upload</button>
    </form>
  );
}

export default UploadPortal;
