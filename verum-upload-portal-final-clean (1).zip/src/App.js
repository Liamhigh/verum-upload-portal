import React, { useState } from "react";

const App = () => {
  const [selectedType, setSelectedType] = useState("");
  const [file, setFile] = useState(null);

  const handleUpload = (e) => {
    e.preventDefault();
    if (file) {
      alert(`Uploaded: ${file.name} as ${selectedType}`);
    }
  };

  return (
    <div style={{ padding: 20, fontFamily: "Arial" }}>
      <img src="https://verumglobal.foundation/logo.png" alt="Verum Omnis Logo" style={{ maxWidth: 120 }} />
      <h1>Verum Omnis Upload Portal</h1>
      <p>Select your role:</p>
      <select value={selectedType} onChange={(e) => setSelectedType(e.target.value)}>
        <option value="">Select type</option>
        <option value="private">Private Individual</option>
        <option value="company">Company</option>
        <option value="institution">Institution</option>
      </select>
      <form onSubmit={handleUpload} style={{ marginTop: 20 }}>
        <input type="file" onChange={(e) => setFile(e.target.files[0])} />
        <button type="submit" style={{ marginLeft: 10 }}>Upload</button>
      </form>
    </div>
  );
};

export default App;
