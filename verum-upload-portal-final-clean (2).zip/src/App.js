import React, { useState } from "react";
import UploadPortal from "./UploadPortal";

function App() {
  return (
    <div style={{ padding: "2rem", fontFamily: "serif" }}>
      <img src="/verum-logo.png" alt="Verum Omnis Logo" style={{ maxWidth: 200 }} />
      <h1 style={{ fontSize: "2rem", marginTop: "1rem" }}>Welcome to Verum Omnis Frontend</h1>
      <p style={{ fontSize: "1.2rem" }}>
        The world's first forensic AI platform — self-verifying, sealed, and secured.
      </p>
      <UploadPortal />
    </div>
  );
}

export default App;