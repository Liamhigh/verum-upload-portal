import React, { useState } from "react";

function UploadPortal() {
  const [file, setFile] = useState(null);

  const handleChange = (e) => {
    setFile(e.target.files[0]);
  };

  const handleUpload = () => {
    if (file) {
      alert("Pretend this file was uploaded: " + file.name);
    } else {
      alert("No file selected");
    }
  };

  return (
    <div style={{ marginTop: "2rem" }}>
      <h2>Upload your documents</h2>
      <input type="file" onChange={handleChange} />
      <button onClick={handleUpload} style={{ marginLeft: "1rem" }}>Upload</button>
    </div>
  );
}

export default UploadPortal;